enum
{
	// End of symbol definition
	VERHORLINE_SHADER=10000,
	_DUMMY_ELEMENT_
};
